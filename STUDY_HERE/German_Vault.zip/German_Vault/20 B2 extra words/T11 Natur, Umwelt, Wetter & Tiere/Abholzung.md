---
title: "Abholzung"
type: "word"
aliases: ["die Abholzung"]
lemma: "Abholzung"
meaning: "deforestation; felling"
pos: "noun"
article: "die"
plural: "–"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0730"
exam_use: ["Lesen", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# die Abholzung

**Meaning:** deforestation; felling
**Plural:** –
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Die Abholzung der Wälder trägt zum Klimawandel bei.
> *Deforestation of the forests contributes to climate change.*

**Collocations**
- Abholzung stoppen
- illegale Abholzung
- Abholzung des Regenwaldes

**Related:** [[stoppen]]

**Exam use:** Lesen, Hören
<!-- bank:end -->

## My notes

