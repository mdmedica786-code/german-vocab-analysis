---
title: "Sonnenlicht"
type: "word"
aliases: ["das Sonnenlicht"]
lemma: "Sonnenlicht"
meaning: "sunlight"
pos: "noun"
article: "das"
plural: "–"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D3279"
exam_use: ["Alltag", "Lesen"]
skip: false
status: "new"
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Alltag", "exam/Lesen"]
---
<!-- bank:start -->
# das Sonnenlicht

**Meaning:** sunlight
**Plural:** –
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Die Pflanze braucht viel Sonnenlicht.
> *The plant needs a lot of sunlight.*

**Collocations**
- direktes Sonnenlicht
- im Sonnenlicht
- warmes Sonnenlicht

**Exam use:** Alltag, Lesen
<!-- bank:end -->

## My notes

