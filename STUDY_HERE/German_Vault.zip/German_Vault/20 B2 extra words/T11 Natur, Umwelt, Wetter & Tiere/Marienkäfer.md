---
title: "Marienkäfer"
type: "word"
aliases: ["der Marienkäfer"]
lemma: "Marienkäfer"
meaning: "ladybird"
pos: "noun"
article: "der"
plural: "Marienkäfer"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D1953"
exam_use: ["Alltag", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Alltag", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# der Marienkäfer

**Meaning:** ladybird
**Plural:** Marienkäfer
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Auf dem Blatt saß ein roter Marienkäfer mit schwarzen Punkten.
> *A red ladybird with black dots sat on the leaf.*

**Collocations**
- ein Marienkäfer sitzt
- Marienkäfer fressen Blattläuse
- der Marienkäfer als Glücksbringer

**Related:** [[fressen]]

**Exam use:** Alltag, Hören
<!-- bank:end -->

## My notes

