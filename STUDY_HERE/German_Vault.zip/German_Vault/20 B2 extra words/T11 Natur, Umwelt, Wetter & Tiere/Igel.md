---
title: "Igel"
type: "word"
aliases: ["der Igel"]
lemma: "Igel"
meaning: "hedgehog"
pos: "noun"
article: "der"
plural: "Igel"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D1950"
exam_use: ["Alltag", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Alltag", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# der Igel

**Meaning:** hedgehog
**Plural:** Igel
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Im Herbst sucht der Igel einen Platz für den Winterschlaf.
> *In autumn the hedgehog looks for a place for hibernation.*

**Collocations**
- einen Igel finden
- der Igel hält Winterschlaf
- einen Igel im Garten

**Related:** [[Winterschlaf]] · [[Garten]]

**Exam use:** Alltag, Hören
<!-- bank:end -->

## My notes

