---
title: "Mülldeponie"
type: "word"
aliases: ["die Mülldeponie", "Mülldeponien"]
lemma: "Mülldeponie"
meaning: "landfill"
pos: "noun"
article: "die"
plural: "Mülldeponien"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D2030"
exam_use: ["Lesen", "Medien"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen", "exam/Medien"]
status: "new"
---
<!-- bank:start -->
# die Mülldeponie

**Meaning:** landfill
**Plural:** Mülldeponien
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Der Müll wird auf einer Mülldeponie außerhalb der Stadt gelagert.
> *The waste is stored on a landfill outside the city.*

**Collocations**
- eine Mülldeponie schließen
- Müll auf der Deponie
- wilde Mülldeponie

**Related:** [[Müll]] · [[Deponie]]

**Exam use:** Lesen, Medien
<!-- bank:end -->

## My notes

