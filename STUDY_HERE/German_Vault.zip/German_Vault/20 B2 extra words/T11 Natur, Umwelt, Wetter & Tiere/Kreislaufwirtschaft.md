---
title: "Kreislaufwirtschaft"
type: "word"
aliases: ["die Kreislaufwirtschaft"]
lemma: "Kreislaufwirtschaft"
meaning: "circular economy"
pos: "noun"
article: "die"
plural: "–"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0673"
exam_use: ["Lesen"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen"]
status: "new"
---
<!-- bank:start -->
# die Kreislaufwirtschaft

**Meaning:** circular economy
**Plural:** –
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Die Kreislaufwirtschaft soll Abfälle vermeiden und Rohstoffe wiederverwenden.
> *The circular economy is meant to avoid waste and reuse raw materials.*

**Collocations**
- auf Kreislaufwirtschaft setzen
- Kreislaufwirtschaft fördern
- Prinzip der Kreislaufwirtschaft

**Related:** [[fördern]] · [[Prinzip]]

**Exam use:** Lesen
<!-- bank:end -->

## My notes

