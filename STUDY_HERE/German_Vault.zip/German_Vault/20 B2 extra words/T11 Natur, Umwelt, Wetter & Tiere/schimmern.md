---
title: "schimmern"
type: "word"
aliases: ["schimmert", "schimmerte", "hat geschimmert"]
lemma: "schimmern"
meaning: "to shimmer; to glimmer"
pos: "verb"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D1718"
exam_use: ["Lesen", "Medien"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/verb", "exam/Lesen", "exam/Medien"]
status: "new"
---
<!-- bank:start -->
# schimmern

**Meaning:** to shimmer; to glimmer
**Forms:** schimmert · schimmerte · hat geschimmert
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Das Wasser schimmerte im Mondlicht.
> *The water shimmered in the moonlight.*

**Collocations**
- im Licht schimmern
- silbern schimmern
- schimmernde Perlen

**Related:** [[Licht]]

**Exam use:** Lesen, Medien
<!-- bank:end -->

## My notes

