---
title: "Frost"
type: "word"
aliases: ["der Frost", "Fröste"]
lemma: "Frost"
meaning: "frost"
pos: "noun"
article: "der"
plural: "Fröste"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0715"
exam_use: ["Hören", "Alltag"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Hören", "exam/Alltag"]
status: "new"
---
<!-- bank:start -->
# der Frost

**Meaning:** frost
**Plural:** Fröste
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> In der Nacht gibt es Frost, auch am Boden.
> *Tonight there will be frost, including ground frost.*

**Collocations**
- leichter Frost
- Frost und Schnee
- vor Frost schützen

**Related:** [[Schnee]] · [[schützen]]

**Exam use:** Hören, Alltag
<!-- bank:end -->

## My notes

