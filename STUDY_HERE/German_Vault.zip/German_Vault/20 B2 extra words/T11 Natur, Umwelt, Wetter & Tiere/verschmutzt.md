---
title: "verschmutzt"
type: "word"
lemma: "verschmutzt"
meaning: "dirty; polluted"
pos: "adjective"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D2338"
exam_use: ["Lesen", "Schreiben"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/adjective", "exam/Lesen", "exam/Schreiben"]
status: "new"
---
<!-- bank:start -->
# verschmutzt

**Meaning:** dirty; polluted
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Der Fluss ist stark verschmutzt.
> *The river is heavily polluted.*

**Collocations**
- stark verschmutzt
- verschmutztes Wasser
- verschmutzte Kleidung

**Related:** [[stark]] · [[Wasser]] · [[Kleidung]]

**Exam use:** Lesen, Schreiben
<!-- bank:end -->

## My notes

