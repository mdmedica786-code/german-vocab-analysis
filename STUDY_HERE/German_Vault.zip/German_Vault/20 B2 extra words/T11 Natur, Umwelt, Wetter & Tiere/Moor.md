---
title: "Moor"
type: "word"
aliases: ["das Moor", "Moore"]
lemma: "Moor"
meaning: "bog; moor"
pos: "noun"
article: "das"
plural: "Moore"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0744"
exam_use: ["Lesen"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen"]
status: "new"
---
<!-- bank:start -->
# das Moor

**Meaning:** bog; moor
**Plural:** Moore
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Das Moor ist ein wichtiger Speicher für Kohlenstoff.
> *The bog is an important store for carbon.*

**Collocations**
- ein Moor schützen
- durch das Moor wandern
- Moore wiedervernässen

**Related:** [[schützen]]

**Exam use:** Lesen
<!-- bank:end -->

## My notes

