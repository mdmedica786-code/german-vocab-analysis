---
title: "Hochdruck"
type: "word"
aliases: ["der Hochdruck"]
lemma: "Hochdruck"
meaning: "high pressure"
pos: "noun"
article: "der"
plural: "–"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0720"
exam_use: ["Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# der Hochdruck

**Meaning:** high pressure
**Plural:** –
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Über Mitteleuropa herrscht Hochdruck, deshalb bleibt es sonnig und trocken.
> *High pressure prevails over central Europe, so it stays sunny and dry.*

**Collocations**
- unter Hochdruck
- Hochdruckgebiet
- Hochdruck über Mitteleuropa

**Exam use:** Hören
<!-- bank:end -->

## My notes

