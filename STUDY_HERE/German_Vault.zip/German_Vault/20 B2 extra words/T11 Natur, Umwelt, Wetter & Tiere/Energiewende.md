---
title: "Energiewende"
type: "word"
aliases: ["die Energiewende"]
lemma: "Energiewende"
meaning: "energy transition"
pos: "noun"
article: "die"
plural: "–"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0653"
exam_use: ["Lesen", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# die Energiewende

**Meaning:** energy transition
**Plural:** –
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Die Energiewende soll den Ausstoß von Treibhausgasen senken.
> *The energy transition is meant to reduce greenhouse gas emissions.*

**Collocations**
- die Energiewende vorantreiben
- Kosten der Energiewende
- Energiewende in Deutschland

**Related:** [[Kosten]] · [[Deutschland]]

**Exam use:** Lesen, Hören
<!-- bank:end -->

## My notes

