---
title: "Artensterben"
type: "word"
aliases: ["das Artensterben"]
lemma: "Artensterben"
meaning: "species extinction"
pos: "noun"
article: "das"
plural: "–"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0657"
exam_use: ["Lesen", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# das Artensterben

**Meaning:** species extinction
**Plural:** –
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Das Artensterben nimmt weltweit zu.
> *Species extinction is increasing worldwide.*

**Collocations**
- das Artensterben stoppen
- das Artensterben beschleunigen
- massives Artensterben

**Related:** [[stoppen]] · [[beschleunigen]]

**Exam use:** Lesen, Hören
<!-- bank:end -->

## My notes

