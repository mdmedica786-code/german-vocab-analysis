---
title: "Stausee"
type: "word"
aliases: ["der Stausee", "Stauseen"]
lemma: "Stausee"
meaning: "reservoir"
pos: "noun"
article: "der"
plural: "Stauseen"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D2010"
exam_use: ["Lesen", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# der Stausee

**Meaning:** reservoir
**Plural:** Stauseen
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Der Stausee liefert Trinkwasser für die Stadt.
> *The reservoir supplies drinking water for the city.*

**Collocations**
- am Stausee
- ein künstlicher Stausee
- der Stausee ist voll

**Related:** [[voll]]

**Exam use:** Lesen, Hören
<!-- bank:end -->

## My notes

