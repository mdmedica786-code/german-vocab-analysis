---
title: "diesig"
type: "word"
lemma: "diesig"
meaning: "hazy; misty"
pos: "adjective"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D2295"
exam_use: ["Hören", "Lesen"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/adjective", "exam/Hören", "exam/Lesen"]
status: "new"
---
<!-- bank:start -->
# diesig

**Meaning:** hazy; misty
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Es war diesig, deshalb sah man die Berge nicht.
> *It was hazy, so the mountains could not be seen.*

**Collocations**
- diesiges Wetter
- diesig sein
- ein diesiger Morgen

**Related:** [[Wetter]] · [[Morgen]]

**Exam use:** Hören, Lesen
<!-- bank:end -->

## My notes

