---
title: "Adler"
type: "word"
aliases: ["der Adler"]
lemma: "Adler"
meaning: "eagle"
pos: "noun"
article: "der"
plural: "Adler"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D3032"
exam_use: ["Lesen", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# der Adler

**Meaning:** eagle
**Plural:** Adler
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Der Adler kreiste hoch über dem Tal.
> *The eagle circled high above the valley.*

**Collocations**
- ein Adler kreist
- der Adler als Wappentier
- Adler und Falke

**Exam use:** Lesen, Hören
<!-- bank:end -->

## My notes

