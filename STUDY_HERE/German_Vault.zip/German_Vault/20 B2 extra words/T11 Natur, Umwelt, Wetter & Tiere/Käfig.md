---
title: "Käfig"
type: "word"
aliases: ["der Käfig", "Käfige"]
lemma: "Käfig"
meaning: "cage"
pos: "noun"
article: "der"
plural: "Käfige"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D1422"
exam_use: ["Alltag", "Lesen"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Alltag", "exam/Lesen"]
status: "new"
---
<!-- bank:start -->
# der Käfig

**Meaning:** cage
**Plural:** Käfige
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Der Vogel sitzt in einem großen Käfig.
> *The bird is sitting in a large cage.*

**Collocations**
- im Käfig halten
- ein Käfig für Hamster
- den Käfig reinigen

**Related:** [[Hamster]] · [[reinigen]]

**Exam use:** Alltag, Lesen
<!-- bank:end -->

## My notes

