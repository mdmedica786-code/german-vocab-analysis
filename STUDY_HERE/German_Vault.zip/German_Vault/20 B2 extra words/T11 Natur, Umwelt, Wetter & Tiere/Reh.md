---
title: "Reh"
type: "word"
aliases: ["das Reh", "Rehe"]
lemma: "Reh"
meaning: "roe deer"
pos: "noun"
article: "das"
plural: "Rehe"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D1955"
exam_use: ["Alltag", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Alltag", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# das Reh

**Meaning:** roe deer
**Plural:** Rehe
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Abends kommen Rehe an den Waldrand.
> *In the evening roe deer come to the edge of the forest.*

**Collocations**
- ein Reh im Wald
- Rehe füttern
- Rehe beobachten

**Related:** [[Wald]] · [[beobachten]]

**Exam use:** Alltag, Hören
<!-- bank:end -->

## My notes

