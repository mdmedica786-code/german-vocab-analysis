---
title: "Bach"
type: "word"
aliases: ["der Bach", "Bäche"]
lemma: "Bach"
meaning: "brook; stream"
pos: "noun"
article: "der"
plural: "Bäche"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0742"
exam_use: ["Alltag", "Lesen"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Alltag", "exam/Lesen"]
status: "new"
---
<!-- bank:start -->
# der Bach

**Meaning:** brook; stream
**Plural:** Bäche
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Hinter dem Haus fließt ein kleiner Bach.
> *A small brook flows behind the house.*

**Collocations**
- ein Bach plätschert
- am Bach spielen
- über den Bach springen

**Related:** [[springen]]

**Exam use:** Alltag, Lesen
<!-- bank:end -->

## My notes

