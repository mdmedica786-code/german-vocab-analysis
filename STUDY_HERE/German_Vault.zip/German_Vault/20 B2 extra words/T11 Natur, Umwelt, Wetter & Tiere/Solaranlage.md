---
title: "Solaranlage"
type: "word"
aliases: ["die Solaranlage", "Solaranlagen"]
lemma: "Solaranlage"
meaning: "solar power system; solar panels"
pos: "noun"
article: "die"
plural: "Solaranlagen"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D0648"
exam_use: ["Alltag", "Lesen"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Alltag", "exam/Lesen"]
status: "new"
---
<!-- bank:start -->
# die Solaranlage

**Meaning:** solar power system; solar panels
**Plural:** Solaranlagen
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Auf dem Dach der Schule steht eine Solaranlage.
> *There is a solar power system on the roof of the school.*

**Collocations**
- eine Solaranlage installieren
- Solaranlage auf dem Dach
- Solaranlage betreiben

**Related:** [[installieren]] · [[Dach]] · [[betreiben]]

**Exam use:** Alltag, Lesen
<!-- bank:end -->

## My notes

