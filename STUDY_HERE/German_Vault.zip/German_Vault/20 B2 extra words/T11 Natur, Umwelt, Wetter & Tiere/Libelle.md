---
title: "Libelle"
type: "word"
aliases: ["die Libelle", "Libellen"]
lemma: "Libelle"
meaning: "dragonfly"
pos: "noun"
article: "die"
plural: "Libellen"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D1952"
exam_use: ["Lesen", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# die Libelle

**Meaning:** dragonfly
**Plural:** Libellen
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Am Teich flog eine blaue Libelle.
> *A blue dragonfly was flying at the pond.*

**Collocations**
- eine Libelle fliegt
- am Teich Libellen beobachten
- schillernde Libelle

**Related:** [[Teich]] · [[beobachten]]

**Exam use:** Lesen, Hören
<!-- bank:end -->

## My notes

