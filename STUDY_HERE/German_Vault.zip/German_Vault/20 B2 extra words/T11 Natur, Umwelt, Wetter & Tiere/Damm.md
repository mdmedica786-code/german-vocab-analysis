---
title: "Damm"
type: "word"
aliases: ["der Damm", "Dämme"]
lemma: "Damm"
meaning: "dam; embankment"
pos: "noun"
article: "der"
plural: "Dämme"
level: "B2"
topic: "[[T11 Natur, Umwelt, Wetter & Tiere]]"
register: "neutral"
bank: "b2"
id: "D2012"
exam_use: ["Lesen", "Hören"]
skip: false
tags: ["vocab", "bank/b2", "level/B2", "topic/T11", "pos/noun", "exam/Lesen", "exam/Hören"]
status: "new"
---
<!-- bank:start -->
# der Damm

**Meaning:** dam; embankment
**Plural:** Dämme
**Level:** B2 · **Topic:** [[T11 Natur, Umwelt, Wetter & Tiere]] · **Register:** neutral

> [!example] Beispiel
> Ein Damm schützt das Dorf vor Hochwasser.
> *An embankment protects the village from flooding.*

**Collocations**
- einen Damm bauen
- der Damm bricht
- auf dem Damm sein

**Exam use:** Lesen, Hören
<!-- bank:end -->

## My notes

