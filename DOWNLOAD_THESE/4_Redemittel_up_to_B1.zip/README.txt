REDEMITTEL UP TO B1
===================

Redemittel_A2_B1.csv  all 642 (A2: 93, B1: 549), sorted by level, then topic
Redemittel_A2.csv     93 A2 Redemittel (learn first)
Redemittel_B1.csv     549 B1 Redemittel (Goethe B1 Sprechen / Schreiben, FSP basics)

There are no A1 Redemittel in the bank. Columns: id, cat_id, category, function, speaker, level, priority
(core = learn first), redemittel_de, meaning_en, example_de, example_en, variants, grammar_note, exam_use.
Open the CSV in Excel with encoding UTF-8. Redemittel of level B2/C1 are in WORD_LISTS/redemittel.csv.
