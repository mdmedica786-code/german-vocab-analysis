Input files for the nerdmedica-de-pro skill (one per level).
Example: python scripts/build_deck.py --words anki_json/A1.json --name "German_PRO_v3::bank::A1" --deck-id 2002001001 --out German_PRO_A1.apkg --audio native+edge
Do not change any German in the files.
