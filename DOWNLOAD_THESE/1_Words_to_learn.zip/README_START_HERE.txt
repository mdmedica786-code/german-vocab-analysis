YOUR WORDS TO LEARN
===================

Learn in this order (your plan: Goethe B1 in December 2026, B2 in spring 2027, then FSP):

  1_B1_exam_Dec2026/     A1.csv  ->  A2.csv  ->  B1.csv           (5,457 words)
  2_B2_exam_2027/        B2.csv  (359 core B2 words)  then  B2_extra.csv (4,684 more B2 words)
  3_C1_later/            C1.csv                                    (252 words)
  4_Phrases_and_Redemittel/   phrases.csv (1,016) and redemittel.csv (1,176: ready-made sentences for speaking and writing)

Other files
  Word_Lists_by_Level.xlsx   the same words in Excel (filter by level, topic, type)
  ALL_WORDS.csv              everything in one file (10,752 words); give this to an AI model

How to read a CSV: open with Excel ("Data > From text/CSV", encoding UTF-8) or give it to your AI model.
Columns: id, level, topic, type, german, word, article, plural, forms, grammar, meaning_en, example_de,
example_en, collocations, exam_use, register, medical, bank, note.

The 456 words that were left out on purpose (country names, duplicates, Austrian/Swiss-only words) are NOT in
these files. You do not need to learn them.
