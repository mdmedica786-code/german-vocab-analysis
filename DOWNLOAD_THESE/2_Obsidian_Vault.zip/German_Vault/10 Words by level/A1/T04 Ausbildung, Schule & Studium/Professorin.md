---
title: "Professorin"
type: "word"
aliases: ["die Professorin", "Professorinnen"]
lemma: "Professorin"
meaning: "professor (f)"
pos: "noun"
article: "die"
plural: "Professorinnen"
level: "A1"
topic: "[[T04 Ausbildung, Schule & Studium]]"
register: "neutral"
bank: "main"
id: "B1496"
goethe_level: "B1"
netzwerk: "A1 K10 3a"
freq_rank: 5759
skip: false
audio: "Professorin.wav"
tags: ["vocab", "bank/main", "level/A1", "topic/T04", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# die Professorin

![[Professorin.wav]]

[▶️ YouGlish](https://youglish.com/pronounce/Professorin/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Professorin&language=de)

**Meaning:** professor (f)
**Plural:** Professorinnen
**Level:** A1 · **Topic:** [[T04 Ausbildung, Schule & Studium]] · **Register:** neutral

> [!example] Beispiel
> Unsere Nachbarin ist Professorin an der Universität.
> *Our neighbour is a professor at the university.*

**Phrases & Expressions:**
- **Unsere Nachbarin ist Professorin an der Universität** — *Our neighbour is a professor at the university* *(Beispiel im Kontext)*

**Source:** Netzwerk neu A1 K10 3a (Studium und Beruf) · Goethe word list B1
<!-- bank:end -->

## My notes

