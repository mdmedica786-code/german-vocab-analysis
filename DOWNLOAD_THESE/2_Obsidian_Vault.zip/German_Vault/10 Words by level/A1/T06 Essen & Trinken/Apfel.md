---
title: "Apfel"
type: "word"
aliases: ["der Apfel", "Äpfel"]
lemma: "Apfel"
meaning: "apple"
pos: "noun"
article: "der"
plural: "Äpfel"
level: "A1"
topic: "[[T06 Essen & Trinken]]"
register: "neutral"
bank: "main"
id: "B0634"
goethe_level: "A1"
netzwerk: "A1 K4 2b"
freq_rank: 4580
skip: false
audio: "Apfel.wav"
tags: ["vocab", "bank/main", "level/A1", "topic/T06", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Apfel

![[Apfel.wav]]

![[Apfel.jpg]]

[▶️ YouGlish](https://youglish.com/pronounce/Apfel/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Apfel&language=de)

**Meaning:** apple
**Plural:** Äpfel
**Level:** A1 · **Topic:** [[T06 Essen & Trinken]] · **Register:** neutral

> [!example] Beispiel
> Ein Pfund Äpfel bitte.
> *A pound of apples, please.*

**Phrases & Expressions:**
- **Ein Pfund Äpfel bitte** — *A pound of apples, please* *(Beispiel im Kontext)*

**Source:** Netzwerk neu A1 K4 2b (Guten Appetit!) · Goethe word list A1
<!-- bank:end -->

## My notes

