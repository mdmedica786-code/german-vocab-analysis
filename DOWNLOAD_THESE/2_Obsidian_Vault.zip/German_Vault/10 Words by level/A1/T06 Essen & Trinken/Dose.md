---
title: "Dose"
type: "word"
aliases: ["die Dose", "Dosen"]
lemma: "Dose"
meaning: "tin; can"
pos: "noun"
article: "die"
plural: "Dosen"
level: "A1"
topic: "[[T06 Essen & Trinken]]"
register: "neutral"
bank: "main"
id: "B0691"
goethe_level: "B1"
netzwerk: "A1 K4 6d ÜB"
freq_rank: 3466
skip: false
audio: "Dose.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T06", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# die Dose

![[Dose.ogg]]

![[Dose.jpg]]

[▶️ YouGlish](https://youglish.com/pronounce/Dose/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Dose&language=de)

**Meaning:** tin; can
**Plural:** Dosen
**Level:** A1 · **Topic:** [[T06 Essen & Trinken]] · **Register:** neutral

> [!example] Beispiel
> Ich habe noch eine Dose Bohnen.
> *I still have a tin of beans.*

**Phrases & Expressions:**
- **Ich habe noch eine Dose Bohnen** — *I still have a tin of beans* *(Beispiel im Kontext)*

**Source:** Netzwerk neu A1 K4 6d ÜB (Guten Appetit!) · Goethe word list B1
<!-- bank:end -->

## My notes

