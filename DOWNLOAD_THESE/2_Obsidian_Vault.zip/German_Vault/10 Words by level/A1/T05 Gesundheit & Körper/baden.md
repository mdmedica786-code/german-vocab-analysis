---
title: "baden"
type: "word"
aliases: ["badet", "badete", "hat gebadet"]
lemma: "baden"
meaning: "to bath"
pos: "verb"
level: "A1"
topic: "[[T05 Gesundheit & Körper]]"
register: "neutral"
bank: "main"
id: "B1277"
goethe_level: "A1"
netzwerk: "A1 K8 10b"
freq_rank: 2010
skip: false
audio: "baden.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T05", "pos/verb"]
status: "new"
---
<!-- bank:start -->
# baden

![[baden.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/baden/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=baden&language=de)

**Meaning:** to bath
**Forms:** badet · badete · hat gebadet
**Level:** A1 · **Topic:** [[T05 Gesundheit & Körper]] · **Register:** neutral

> [!example] Beispiel
> Ich bade nicht so gern, ich dusche lieber.
> *I don't like taking baths, I prefer to shower.*

**Phrases & Expressions:**
- **Ich bade nicht so gern, ich dusche lieber** — *I don't like taking baths, I prefer to shower* *(Beispiel im Kontext)*

**Source:** Netzwerk neu A1 K8 10b (Fit und gesund) · Goethe word list A1
<!-- bank:end -->

## My notes

