---
title: "Fuß"
type: "word"
aliases: ["der Fuß", "Füße"]
lemma: "Fuß"
meaning: "foot"
pos: "noun"
article: "der"
plural: "Füße"
level: "A1"
topic: "[[T05 Gesundheit & Körper]]"
register: "neutral"
bank: "main"
id: "B1233"
goethe_level: "A1"
netzwerk: "A1 K8 6a"
freq_rank: 462
skip: false
audio: "Fuß.wav"
tags: ["vocab", "bank/main", "level/A1", "topic/T05", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# der Fuß

![[Fuß.jpg]]

![[Fuß.wav]]

[▶️ YouGlish](https://youglish.com/pronounce/Fu%C3%9F/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Fu%C3%9F&language=de)

**Meaning:** foot
**Plural:** Füße
**Level:** A1 · **Topic:** [[T05 Gesundheit & Körper]] · **Register:** neutral

> [!example] Beispiel
> Der linke Fuß tut mir weh.
> *My left foot hurts.*

**Phrases & Expressions:**
- **zu Fuß** — on foot *([[Ort - Richtung (location, direction)|Ort / Richtung (location, direction)]] · A1)*

**Source:** Netzwerk neu A1 K8 6a (Fit und gesund) · Goethe word list A1
<!-- bank:end -->

## My notes

