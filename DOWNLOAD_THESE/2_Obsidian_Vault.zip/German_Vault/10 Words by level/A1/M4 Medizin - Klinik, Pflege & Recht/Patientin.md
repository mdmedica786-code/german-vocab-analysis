---
title: "Patientin"
type: "word"
aliases: ["die Patientin", "Patientinnen"]
lemma: "Patientin"
meaning: "patient (f)"
pos: "noun"
article: "die"
plural: "Patientinnen"
level: "A1"
topic: "[[M4 Medizin - Klinik, Pflege & Recht]]"
register: "neutral"
bank: "main"
id: "B0333"
goethe_level: "B1"
netzwerk: "A1 K2 7a"
freq_rank: 3260
skip: false
audio: "Patientin.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/M4", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# die Patientin

![[Patientin.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/Patientin/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Patientin&language=de)

**Meaning:** patient (f)
**Plural:** Patientinnen
**Level:** A1 · **Topic:** [[M4 Medizin - Klinik, Pflege & Recht]] · **Register:** neutral

> [!example] Beispiel
> Ich bin Patientin bei Dr. Hausner. Ich möchte bitte einen Termin.
> *I'm a patient of Dr Hausner. I'd like an appointment, please.*

**Phrases & Expressions:**
- **die Patientin aufklären** — *patient (f)*
- **die Patientin untersuchen** — *patient (f)*
- **die Patientin aufnehmen** — *patient (f)*
- **Patientin mit ...** — *patient (f)*

**Collocations**
- die Patientin aufklären
- die Patientin untersuchen
- die Patientin aufnehmen
- Patientin mit ...

**Related:** [[aufklären]]

**Source:** Netzwerk neu A1 K2 7a (Freunde, Kollegen und ich) · Goethe word list B1
<!-- bank:end -->

## My notes

