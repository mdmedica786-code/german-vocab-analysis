---
title: "Architektin"
type: "word"
aliases: ["die Architektin", "Architektinnen"]
lemma: "Architektin"
meaning: "architect (f)"
pos: "noun"
article: "die"
plural: "Architektinnen"
level: "A1"
topic: "[[T03 Arbeit & Beruf]]"
register: "neutral"
bank: "main"
id: "B0359"
goethe_level: "B1"
netzwerk: "A1 K2 9a"
freq_rank: 5759
skip: false
audio: "Architektin.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T03", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# die Architektin

![[Architektin.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/Architektin/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Architektin&language=de)

**Meaning:** architect (f)
**Plural:** Architektinnen
**Level:** A1 · **Topic:** [[T03 Arbeit & Beruf]] · **Register:** neutral

> [!example] Beispiel
> Dieses Haus hat eine berühmte Architektin gebaut.
> *A famous woman architect built this house.*

**Phrases & Expressions:**
- **Dieses Haus hat eine berühmte Architektin gebaut** — *A famous woman architect built this house* *(Beispiel im Kontext)*

**Source:** Netzwerk neu A1 K2 9a (Freunde, Kollegen und ich) · Goethe word list B1
<!-- bank:end -->

## My notes

