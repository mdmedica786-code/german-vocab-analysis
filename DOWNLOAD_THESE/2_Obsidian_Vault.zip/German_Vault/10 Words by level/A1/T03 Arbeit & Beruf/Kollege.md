---
title: "Kollege"
type: "word"
aliases: ["der Kollege", "Kollegen"]
lemma: "Kollege"
meaning: "colleague (m)"
pos: "noun"
article: "der"
plural: "Kollegen"
level: "A1"
topic: "[[T03 Arbeit & Beruf]]"
register: "neutral"
bank: "main"
id: "B0206"
goethe_level: "A1"
netzwerk: "A1 K2 2a"
freq_rank: 978
skip: false
audio: "Kollege.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T03", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Kollege

![[Kollege.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/Kollege/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Kollege&language=de)

**Meaning:** colleague (m)
**Plural:** Kollegen
**Level:** A1 · **Topic:** [[T03 Arbeit & Beruf]] · **Register:** neutral

> [!example] Beispiel
> Ich habe guten Kontakt zu meinen Kollegen.
> *I have good contact with my colleagues.*

**Phrases & Expressions:**
- **Bitte warten Sie im Wartebereich, ein Kollege kommt gleich zu Ihnen.** — Please wait in the waiting area; a colleague will come to you shortly. *([[FSP-16 Notfall, Triage und Anweisungen im Team|Angehörige informieren]] · B1)*
- **Sehr geehrte Frau Kollegin, sehr geehrter Herr Kollege,** — Dear colleague (female), dear colleague (male), *([[FSP-20 Arztbrief und Dokumentation|Anrede und Anlass]] · B2)*

**Source:** Netzwerk neu A1 K2 2a (Freunde, Kollegen und ich) · Goethe word list A1
<!-- bank:end -->

## My notes

