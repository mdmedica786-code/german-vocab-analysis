---
title: "Elektriker"
type: "word"
aliases: ["der Elektriker"]
lemma: "Elektriker"
meaning: "electrician (m)"
pos: "noun"
article: "der"
plural: "Elektriker"
level: "A1"
topic: "[[T03 Arbeit & Beruf]]"
register: "neutral"
bank: "main"
id: "B0371"
netzwerk: "A1 K2 9a ÜB"
freq_rank: 5759
skip: false
audio: "Elektriker.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T03", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Elektriker

![[Elektriker.ogg]]

![[Elektriker.jpg]]

[▶️ YouGlish](https://youglish.com/pronounce/Elektriker/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Elektriker&language=de)

**Meaning:** electrician (m)
**Plural:** Elektriker
**Level:** A1 · **Topic:** [[T03 Arbeit & Beruf]] · **Register:** neutral

> [!example] Beispiel
> Der Elektriker repariert die Lampe.
> *The electrician is repairing the lamp.*

**Phrases & Expressions:**
- **Der Elektriker repariert die Lampe** — *The electrician is repairing the lamp* *(Beispiel im Kontext)*

**Source:** Netzwerk neu A1 K2 9a ÜB (Freunde, Kollegen und ich)
<!-- bank:end -->

## My notes

