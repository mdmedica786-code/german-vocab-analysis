---
title: "Gast"
type: "word"
aliases: ["der Gast", "Gäste"]
lemma: "Gast"
meaning: "guest"
pos: "noun"
article: "der"
plural: "Gäste"
level: "A1"
topic: "[[T01 Person, Familie & Beziehungen]]"
register: "neutral"
bank: "main"
id: "B0550"
goethe_level: "A1"
netzwerk: "A1 K3 9a"
freq_rank: 1005
skip: false
audio: "Gast.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T01", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Gast

![[Gast.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/Gast/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Gast&language=de)

**Meaning:** guest
**Plural:** Gäste
**Level:** A1 · **Topic:** [[T01 Person, Familie & Beziehungen]] · **Register:** neutral

> [!example] Beispiel
> Am Wochenende haben wir mehrere Gäste.
> *At the weekend we have several guests.*

**Phrases & Expressions:**
- **Am Wochenende haben wir mehrere Gäste** — *At the weekend we have several guests* *(Beispiel im Kontext)*

**Source:** Netzwerk neu A1 K3 9a (In Hamburg) · Goethe word list A1
<!-- bank:end -->

## My notes

