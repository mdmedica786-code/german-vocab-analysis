---
title: "kennenlernen"
type: "word"
aliases: ["lernt kennen", "lernte kennen", "hat kennengelernt"]
lemma: "kennenlernen"
meaning: "to get to know"
pos: "verb"
level: "A1"
topic: "[[T01 Person, Familie & Beziehungen]]"
register: "neutral"
bank: "main"
id: "B1137"
goethe_level: "A1"
netzwerk: "A1 K7 7a"
freq_rank: 1604
skip: false
audio: "kennenlernen.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T01", "pos/verb"]
status: "new"
---
<!-- bank:start -->
# kennenlernen

![[kennenlernen.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/kennenlernen/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=kennenlernen&language=de)

**Meaning:** to get to know
**Forms:** lernt kennen · lernte kennen · hat kennengelernt
**Grammar:** separable (kennen-)
**Level:** A1 · **Topic:** [[T01 Person, Familie & Beziehungen]] · **Register:** neutral

> [!example] Beispiel
> Wir sind neu hier. Wir möchten Sie kennenlernen.
> *We are new here. We would like to get to know you.*

**Phrases & Expressions:**
- **Kennen wir uns nicht von irgendwoher?** — Don't we know each other from somewhere? *([[B1-20 Smalltalk, Begrüßung und Verabschiedung|Gespräch beginnen]] · B1)*

**Source:** Netzwerk neu A1 K7 7a (Arbeitsalltag) · Goethe word list A1
<!-- bank:end -->

## My notes

