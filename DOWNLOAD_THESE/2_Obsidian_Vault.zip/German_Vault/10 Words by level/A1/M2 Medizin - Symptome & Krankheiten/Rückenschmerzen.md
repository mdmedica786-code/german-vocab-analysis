---
title: "Rückenschmerzen"
type: "word"
aliases: ["die Rückenschmerzen", "(Pl.)"]
lemma: "Rückenschmerzen"
meaning: "back pain"
pos: "noun"
article: "die"
plural: "(Pl.)"
level: "A1"
topic: "[[M2 Medizin - Symptome & Krankheiten]]"
register: "neutral"
bank: "main"
id: "B1288"
netzwerk: "A1 K8 10c"
freq_rank: 5759
skip: false
audio: "Rückenschmerzen.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/M2", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# die Rückenschmerzen

![[Rückenschmerzen.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/R%C3%BCckenschmerzen/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=R%C3%BCckenschmerzen&language=de)

**Meaning:** back pain
**Plural:** (Pl.)
**Level:** A1 · **Topic:** [[M2 Medizin - Symptome & Krankheiten]] · **Register:** neutral

> [!example] Beispiel
> Nach dem langen Sitzen habe ich Rückenschmerzen.
> *After sitting for so long I have back pain.*

**Phrases & Expressions:**
- **Rückenschmerzen haben** — *back pain*
- **chronische Rückenschmerzen** — *back pain*
- **untere Rückenschmerzen** — *back pain*
- **Tabletten gegen Rückenschmerzen** — *back pain*

**Collocations**
- Rückenschmerzen haben
- chronische Rückenschmerzen
- untere Rückenschmerzen
- Tabletten gegen Rückenschmerzen

**Source:** Netzwerk neu A1 K8 10c (Fit und gesund)
<!-- bank:end -->

## My notes

