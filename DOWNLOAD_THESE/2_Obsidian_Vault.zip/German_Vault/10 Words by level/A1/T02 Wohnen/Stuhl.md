---
title: "Stuhl"
type: "word"
aliases: ["der Stuhl", "Stühle"]
lemma: "Stuhl"
meaning: "chair"
pos: "noun"
article: "der"
plural: "Stühle"
level: "A1"
topic: "[[T02 Wohnen]]"
register: "neutral"
bank: "main"
id: "B1364"
goethe_level: "A2"
netzwerk: "A1 K9 1a"
freq_rank: 1163
skip: false
audio: "Stuhl.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T02", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Stuhl

![[Stuhl.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/Stuhl/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=Stuhl&language=de)

**Meaning:** chair
**Plural:** Stühle
**Level:** A1 · **Topic:** [[T02 Wohnen]] · **Register:** neutral

> [!example] Beispiel
> Ist der Stuhl frei?
> *Is this chair free?*

**Phrases & Expressions:**
- **Haben Sie Blut im Stuhl bemerkt?** — Have you noticed blood in your stool? *([[FSP-06 Systemanamnese (Organsysteme)|Magen-Darm]] · B2)*
- **Achten Sie auf Warnzeichen wie Atemnot, Brustschmerzen oder Blut im Stuhl.** — Watch for warning signs such as shortness of breath, chest pain or blood in the stool. *([[FSP-17 Entlassung, Überweisung und Nachsorge|Warnzeichen nennen]] · B2)*

**Source:** Netzwerk neu A1 K9 1a (Meine Wohnung) · Goethe word list A2
<!-- bank:end -->

## My notes

