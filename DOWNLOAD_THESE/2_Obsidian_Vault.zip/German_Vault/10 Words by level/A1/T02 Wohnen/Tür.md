---
title: "Tür"
type: "word"
aliases: ["die Tür", "Türen"]
lemma: "Tür"
meaning: "door"
pos: "noun"
article: "die"
plural: "Türen"
level: "A1"
topic: "[[T02 Wohnen]]"
register: "neutral"
bank: "main"
id: "B1406"
goethe_level: "A2"
netzwerk: "A1 K9 4f ÜB"
freq_rank: 268
skip: false
audio: "Tür.ogg"
tags: ["vocab", "bank/main", "level/A1", "topic/T02", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# die Tür

![[Tür.ogg]]

[▶️ YouGlish](https://youglish.com/pronounce/T%C3%BCr/german) · [🎬 PlayPhrase](https://www.playphrase.me/#/search?q=T%C3%BCr&language=de)

**Meaning:** door
**Plural:** Türen
**Level:** A1 · **Topic:** [[T02 Wohnen]] · **Register:** neutral

> [!example] Beispiel
> Mach bitte die Tür zu!
> *Please close the door!*

**Phrases & Expressions:**
- **Mach bitte die Tür zu** — *Please close the door* *(Beispiel im Kontext)*

**Source:** Netzwerk neu A1 K9 4f ÜB (Meine Wohnung) · Goethe word list A2
<!-- bank:end -->

## My notes

