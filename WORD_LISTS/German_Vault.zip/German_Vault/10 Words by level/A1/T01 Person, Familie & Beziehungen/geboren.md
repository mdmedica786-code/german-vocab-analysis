---
title: "geboren"
type: "word"
lemma: "geboren"
meaning: "to be born"
pos: "adjective"
level: "A1"
topic: "[[T01 Person, Familie & Beziehungen]]"
register: "neutral"
bank: "main"
id: "B1868"
goethe_level: "A1"
netzwerk: "A2 K1 1b"
freq_rank: 510
skip: true
skip_reason: "already learned in an old deck (review interval of 21 days or more)"
tags: ["vocab", "bank/main", "level/A1", "topic/T01", "pos/adjective", "skipped"]
status: "new"
---
<!-- bank:start -->
# geboren

**Meaning:** to be born
**Level:** A1 · **Topic:** [[T01 Person, Familie & Beziehungen]] · **Register:** neutral

> [!info] Not in the study list
> already learned in an old deck (review interval of 21 days or more)

> [!example] Beispiel
> Ich bin in Zagreb geboren.
> **

**Source:** Netzwerk neu A2 K1 1b (Und was machst du?) · Goethe word list A1
<!-- bank:end -->

## My notes

