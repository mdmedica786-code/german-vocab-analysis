---
title: "Großvater"
type: "word"
aliases: ["der Großvater", "Großväter"]
lemma: "Großvater"
meaning: "grandfather"
pos: "noun"
article: "der"
plural: "Großväter"
level: "A1"
topic: "[[T01 Person, Familie & Beziehungen]]"
register: "neutral"
bank: "main"
id: "B0836"
goethe_level: "A1"
netzwerk: "A1 K5 8a ÜB"
freq_rank: 2698
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T01", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Großvater

**Meaning:** grandfather
**Plural:** Großväter
**Level:** A1 · **Topic:** [[T01 Person, Familie & Beziehungen]] · **Register:** neutral

> [!example] Beispiel
> Mein Großvater ist schon 80.
> *My grandfather is already 80.*

**Source:** Netzwerk neu A1 K5 8a ÜB (Alltag und Familie) · Goethe word list A1
<!-- bank:end -->

## My notes

