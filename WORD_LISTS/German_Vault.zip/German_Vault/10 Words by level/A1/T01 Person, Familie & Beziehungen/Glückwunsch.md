---
title: "Glückwunsch"
type: "word"
aliases: ["der Glückwunsch", "Glückwünsche"]
lemma: "Glückwunsch"
meaning: "congratulations"
pos: "noun"
article: "der"
plural: "Glückwünsche"
level: "A1"
topic: "[[T01 Person, Familie & Beziehungen]]"
register: "neutral"
bank: "main"
id: "B1419"
goethe_level: "A1"
netzwerk: "A1 K9 5c"
freq_rank: 2000
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T01", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Glückwunsch

**Meaning:** congratulations
**Plural:** Glückwünsche
**Level:** A1 · **Topic:** [[T01 Person, Familie & Beziehungen]] · **Register:** neutral

> [!example] Beispiel
> Herzlichen Glückwunsch zum Geburtstag.
> *Congratulations on your birthday.*

**Source:** Netzwerk neu A1 K9 5c (Meine Wohnung) · Goethe word list A1
<!-- bank:end -->

## My notes

