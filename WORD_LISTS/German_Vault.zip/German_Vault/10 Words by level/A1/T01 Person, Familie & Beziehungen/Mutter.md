---
title: "Mutter"
type: "word"
aliases: ["die Mutter", "Mütter"]
lemma: "Mutter"
meaning: "mother"
pos: "noun"
article: "die"
plural: "Mütter"
level: "A1"
topic: "[[T01 Person, Familie & Beziehungen]]"
register: "neutral"
bank: "main"
id: "B0807"
goethe_level: "A1"
netzwerk: "A1 K5 7a"
freq_rank: 204
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T01", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# die Mutter

**Meaning:** mother
**Plural:** Mütter
**Level:** A1 · **Topic:** [[T01 Person, Familie & Beziehungen]] · **Register:** neutral

> [!example] Beispiel
> Frau Berghäuser ist die Mutter von Michaela.
> *Mrs Berghäuser is Michaela's mother.*

**Source:** Netzwerk neu A1 K5 7a (Alltag und Familie) · Goethe word list A1
<!-- bank:end -->

## My notes

