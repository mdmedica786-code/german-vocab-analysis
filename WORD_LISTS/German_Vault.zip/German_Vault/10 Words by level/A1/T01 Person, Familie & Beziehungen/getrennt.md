---
title: "getrennt"
type: "word"
lemma: "getrennt"
meaning: "separate"
pos: "adjective"
level: "A1"
topic: "[[T01 Person, Familie & Beziehungen]]"
register: "neutral"
bank: "main"
id: "B0990"
goethe_level: "A2"
netzwerk: "A1 K6 12a"
freq_rank: 1033
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T01", "pos/adjective"]
status: "new"
---
<!-- bank:start -->
# getrennt

**Meaning:** separate
**Level:** A1 · **Topic:** [[T01 Person, Familie & Beziehungen]] · **Register:** neutral

> [!example] Beispiel
> Wir zahlen getrennt, bitte.
> *Separate bills, please.*

**Collocations**
- getrennt leben
- getrennt zahlen
- getrennt schreiben
- getrennt fahren

**Source:** Netzwerk neu A1 K6 12a (Zeit mit Freunden) · Goethe word list A2
<!-- bank:end -->

## My notes

