---
title: "Wohnungsanzeige"
type: "word"
aliases: ["die Wohnungsanzeige", "Wohnungsanzeigen"]
lemma: "Wohnungsanzeige"
meaning: "advertisement for a flat"
pos: "noun"
article: "die"
plural: "Wohnungsanzeigen"
level: "A1"
topic: "[[T02 Wohnen]]"
register: "neutral"
bank: "main"
id: "B1396"
netzwerk: "A1 K9 3c"
freq_rank: 5759
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T02", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# die Wohnungsanzeige

**Meaning:** advertisement for a flat
**Plural:** Wohnungsanzeigen
**Level:** A1 · **Topic:** [[T02 Wohnen]] · **Register:** neutral

> [!example] Beispiel
> Ich habe eine Wohnungsanzeige in der Zeitung gelesen.
> *I read a flat advertisement in the newspaper.*

**Source:** Netzwerk neu A1 K9 3c (Meine Wohnung)
<!-- bank:end -->

## My notes

