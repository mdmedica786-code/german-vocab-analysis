---
title: "Sofa"
type: "word"
aliases: ["das Sofa", "Sofas"]
lemma: "Sofa"
meaning: "sofa, couch"
pos: "noun"
article: "das"
plural: "Sofas"
level: "A1"
topic: "[[T02 Wohnen]]"
register: "neutral"
bank: "main"
id: "B1362"
goethe_level: "A1"
netzwerk: "A1 K9 1a"
freq_rank: 2671
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T02", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# das Sofa

**Meaning:** sofa, couch
**Plural:** Sofas
**Level:** A1 · **Topic:** [[T02 Wohnen]] · **Register:** neutral

> [!example] Beispiel
> Das Sofa ist neu.
> *The sofa is new.*

**Source:** Netzwerk neu A1 K9 1a (Meine Wohnung) · Goethe word list A1
<!-- bank:end -->

## My notes

