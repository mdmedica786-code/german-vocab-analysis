---
title: "hell"
type: "word"
lemma: "hell"
meaning: "light; bright"
pos: "adjective"
level: "A1"
topic: "[[T02 Wohnen]]"
register: "neutral"
bank: "main"
id: "B1374"
goethe_level: "A1"
netzwerk: "A1 K9 3a"
freq_rank: 1012
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T02", "pos/adjective"]
status: "new"
---
<!-- bank:start -->
# hell

**Meaning:** light; bright
**Forms:** heller – am hellsten
**Level:** A1 · **Topic:** [[T02 Wohnen]] · **Register:** neutral

> [!example] Beispiel
> Im Sommer ist es bis 21 Uhr hell.
> *In summer it is light until 9 p.m.*

**Source:** Netzwerk neu A1 K9 3a (Meine Wohnung) · Goethe word list A1
<!-- bank:end -->

## My notes

