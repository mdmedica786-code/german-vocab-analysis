---
title: "umziehen"
type: "word"
aliases: ["zieht um", "zog um", "ist umgezogen"]
lemma: "umziehen"
meaning: "to move"
pos: "verb"
level: "A1"
topic: "[[T02 Wohnen]]"
register: "neutral"
bank: "main"
id: "B1407"
goethe_level: "A1"
netzwerk: "A1 K9 4f ÜB"
freq_rank: 4956
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T02", "pos/verb"]
status: "new"
---
<!-- bank:start -->
# umziehen

**Meaning:** to move
**Forms:** zieht um · zog um · ist umgezogen
**Grammar:** separable (um-)
**Level:** A1 · **Topic:** [[T02 Wohnen]] · **Register:** neutral
**Note:** sich umziehen = to change clothes.

> [!example] Beispiel
> Nächsten Monat ziehen wir um.
> *Next month we are moving.*

**Source:** Netzwerk neu A1 K9 4f ÜB (Meine Wohnung) · Goethe word list A1
<!-- bank:end -->

## My notes

