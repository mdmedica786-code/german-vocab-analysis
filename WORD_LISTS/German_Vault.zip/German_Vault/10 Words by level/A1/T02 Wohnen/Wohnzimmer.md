---
title: "Wohnzimmer"
type: "word"
aliases: ["das Wohnzimmer"]
lemma: "Wohnzimmer"
meaning: "living room"
pos: "noun"
article: "das"
plural: "Wohnzimmer"
level: "A1"
topic: "[[T02 Wohnen]]"
register: "neutral"
bank: "main"
id: "B1369"
goethe_level: "A2"
netzwerk: "A1 K9 1a"
freq_rank: 2071
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T02", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# das Wohnzimmer

**Meaning:** living room
**Plural:** Wohnzimmer
**Level:** A1 · **Topic:** [[T02 Wohnen]] · **Register:** neutral

> [!example] Beispiel
> Die Kinder sitzen im Wohnzimmer und sehen fern.
> *The children are sitting in the living room watching TV.*

**Source:** Netzwerk neu A1 K9 1a (Meine Wohnung) · Goethe word list A2
<!-- bank:end -->

## My notes

