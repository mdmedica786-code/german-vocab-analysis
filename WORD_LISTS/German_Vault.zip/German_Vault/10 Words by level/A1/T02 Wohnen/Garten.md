---
title: "Garten"
type: "word"
aliases: ["der Garten", "Gärten"]
lemma: "Garten"
meaning: "garden"
pos: "noun"
article: "der"
plural: "Gärten"
level: "A1"
topic: "[[T02 Wohnen]]"
register: "neutral"
bank: "main"
id: "B1444"
goethe_level: "A1"
netzwerk: "A1 K9 10a"
freq_rank: 1089
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T02", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Garten

**Meaning:** garden
**Plural:** Gärten
**Level:** A1 · **Topic:** [[T02 Wohnen]] · **Register:** neutral

> [!example] Beispiel
> Wir haben leider keinen Garten.
> *Unfortunately we have no garden.*

**Source:** Netzwerk neu A1 K9 10a (Meine Wohnung) · Goethe word list A1
<!-- bank:end -->

## My notes

