---
title: "Fisch"
type: "word"
aliases: ["der Fisch", "Fische"]
lemma: "Fisch"
meaning: "fish"
pos: "noun"
article: "der"
plural: "Fische"
level: "A1"
topic: "[[T06 Essen & Trinken]]"
register: "neutral"
bank: "main"
id: "B0658"
goethe_level: "A1"
netzwerk: "A1 K4 3c ÜB"
freq_rank: 1995
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T06", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Fisch

**Meaning:** fish
**Plural:** Fische
**Level:** A1 · **Topic:** [[T06 Essen & Trinken]] · **Register:** neutral

> [!example] Beispiel
> Ich esse gern Fisch. Fleisch mag ich nicht.
> *I like eating fish. I don't like meat.*

**Source:** Netzwerk neu A1 K4 3c ÜB (Guten Appetit!) · Goethe word list A1
<!-- bank:end -->

## My notes

