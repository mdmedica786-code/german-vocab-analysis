---
title: "Hähnchen"
type: "word"
aliases: ["das Hähnchen"]
lemma: "Hähnchen"
meaning: "chicken"
pos: "noun"
article: "das"
plural: "Hähnchen"
level: "A1"
topic: "[[T06 Essen & Trinken]]"
register: "neutral"
bank: "main"
id: "B0659"
goethe_level: "A1"
netzwerk: "A1 K4 3c ÜB"
freq_rank: 5759
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T06", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# das Hähnchen

**Meaning:** chicken
**Plural:** Hähnchen
**Level:** A1 · **Topic:** [[T06 Essen & Trinken]] · **Register:** neutral

> [!example] Beispiel
> Ein Hähnchen mit Pommes bitte!
> *A chicken with chips, please!*

**Source:** Netzwerk neu A1 K4 3c ÜB (Guten Appetit!) · Goethe word list A1
<!-- bank:end -->

## My notes

