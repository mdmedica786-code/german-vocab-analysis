---
title: "Döner"
type: "word"
aliases: ["der Döner"]
lemma: "Döner"
meaning: "doner kebab"
pos: "noun"
article: "der"
plural: "Döner"
level: "A1"
topic: "[[T06 Essen & Trinken]]"
register: "neutral"
bank: "main"
id: "B0712"
netzwerk: "A1 K4 9a"
freq_rank: 5746
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T06", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Döner

**Meaning:** doner kebab
**Plural:** Döner
**Level:** A1 · **Topic:** [[T06 Essen & Trinken]] · **Register:** neutral

> [!example] Beispiel
> Ich esse mittags oft einen Döner.
> *At lunchtime I often eat a doner kebab.*

**Source:** Netzwerk neu A1 K4 9a (Guten Appetit!)
<!-- bank:end -->

## My notes

