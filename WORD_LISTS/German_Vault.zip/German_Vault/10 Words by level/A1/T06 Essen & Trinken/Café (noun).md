---
title: "Café"
type: "word"
aliases: ["das Café", "Cafés"]
lemma: "Café"
meaning: "café"
pos: "noun"
article: "das"
plural: "Cafés"
level: "A1"
topic: "[[T06 Essen & Trinken]]"
register: "neutral"
bank: "main"
id: "B5851"
goethe_level: "A1"
freq_rank: 3146
skip: true
skip_reason: "duplicate of B0262 (learn that entry)"
check: "dup:B0262"
tags: ["vocab", "bank/main", "level/A1", "topic/T06", "pos/noun", "skipped"]
status: "new"
---
<!-- bank:start -->
# das Café

**Meaning:** café
**Plural:** Cafés
**Level:** A1 · **Topic:** [[T06 Essen & Trinken]] · **Register:** neutral

> [!info] Not in the study list
> duplicate of B0262 (learn that entry)

> [!warning] Check
> dup:B0262

> [!example] Beispiel
> Sollen wir uns im Café treffen?
> *Shall we meet at the café?*

**Source:** Goethe word list A1
<!-- bank:end -->

## My notes

