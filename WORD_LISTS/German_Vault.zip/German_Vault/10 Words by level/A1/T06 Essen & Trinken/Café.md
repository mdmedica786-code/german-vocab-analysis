---
title: "Café"
type: "word"
aliases: ["das Café", "Cafés"]
lemma: "Café"
meaning: "cafe"
pos: "noun"
article: "das"
plural: "Cafés"
level: "A1"
topic: "[[T06 Essen & Trinken]]"
register: "neutral"
bank: "main"
id: "B0262"
netzwerk: "A1 K2 5b"
freq_rank: 5759
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T06", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# das Café

**Meaning:** cafe
**Plural:** Cafés
**Level:** A1 · **Topic:** [[T06 Essen & Trinken]] · **Register:** neutral

> [!example] Beispiel
> Wir treffen uns im Café am Marktplatz.
> *We're meeting at the café on the market square.*

**Source:** Netzwerk neu A1 K2 5b (Freunde, Kollegen und ich)
<!-- bank:end -->

## My notes

