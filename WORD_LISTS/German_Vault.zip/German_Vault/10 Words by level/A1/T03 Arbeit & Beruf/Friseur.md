---
title: "Friseur"
type: "word"
aliases: ["der Friseur", "Friseure"]
lemma: "Friseur"
meaning: "hairdresser (m)"
pos: "noun"
article: "der"
plural: "Friseure"
level: "A1"
topic: "[[T03 Arbeit & Beruf]]"
register: "neutral"
bank: "main"
id: "B0360"
goethe_level: "A2"
netzwerk: "A1 K2 9a"
freq_rank: 5515
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T03", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# der Friseur

**Meaning:** hairdresser (m)
**Plural:** Friseure
**Level:** A1 · **Topic:** [[T03 Arbeit & Beruf]] · **Register:** neutral

> [!example] Beispiel
> Du siehst toll aus! Wer ist dein Friseur?
> *You look great! Who is your hairdresser?*

**Source:** Netzwerk neu A1 K2 9a (Freunde, Kollegen und ich) · Goethe word list A2
<!-- bank:end -->

## My notes

