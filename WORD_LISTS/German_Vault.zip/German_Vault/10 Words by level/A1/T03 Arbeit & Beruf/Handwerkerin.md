---
title: "Handwerkerin"
type: "word"
aliases: ["die Handwerkerin", "Handwerkerinnen"]
lemma: "Handwerkerin"
meaning: "tradeswoman; craftswoman"
pos: "noun"
article: "die"
plural: "Handwerkerinnen"
level: "A1"
topic: "[[T03 Arbeit & Beruf]]"
register: "neutral"
bank: "main"
id: "B0376"
goethe_level: "A2"
netzwerk: "A1 K2 9a ÜB"
freq_rank: 5759
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T03", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# die Handwerkerin

**Meaning:** tradeswoman; craftswoman
**Plural:** Handwerkerinnen
**Level:** A1 · **Topic:** [[T03 Arbeit & Beruf]] · **Register:** neutral

> [!example] Beispiel
> Die Handwerkerin repariert das Dach.
> *The craftswoman is repairing the roof.*

**Source:** Netzwerk neu A1 K2 9a ÜB (Freunde, Kollegen und ich) · Goethe word list A2
<!-- bank:end -->

## My notes

