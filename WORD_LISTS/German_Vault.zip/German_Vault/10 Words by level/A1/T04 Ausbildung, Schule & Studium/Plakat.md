---
title: "Plakat"
type: "word"
aliases: ["das Plakat", "Plakate"]
lemma: "Plakat"
meaning: "poster"
pos: "noun"
article: "das"
plural: "Plakate"
level: "A1"
topic: "[[T04 Ausbildung, Schule & Studium]]"
register: "neutral"
bank: "main"
id: "B0584"
goethe_level: "A2"
netzwerk: "A1 K3 10d"
freq_rank: 4534
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T04", "pos/noun"]
status: "new"
---
<!-- bank:start -->
# das Plakat

**Meaning:** poster
**Plural:** Plakate
**Level:** A1 · **Topic:** [[T04 Ausbildung, Schule & Studium]] · **Register:** neutral

> [!example] Beispiel
> Wir machen im Unterricht ein Plakat zum Thema „Essen und Trinken“.
> *In class we are making a poster on the topic “Food and Drink”.*

**Source:** Netzwerk neu A1 K3 10d (In Hamburg) · Goethe word list A2
<!-- bank:end -->

## My notes

