---
title: "Krankheit"
type: "word"
aliases: ["die Krankheit", "Krankheiten"]
lemma: "Krankheit"
meaning: "illness"
pos: "noun"
article: "die"
plural: "Krankheiten"
level: "A1"
topic: "[[M2 Medizin - Symptome & Krankheiten]]"
register: "neutral"
bank: "main"
id: "B1159"
goethe_level: "A2"
netzwerk: "A1 K7 9a"
freq_rank: 990
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/M2", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# die Krankheit

**Meaning:** illness
**Plural:** Krankheiten
**Level:** A1 · **Topic:** [[M2 Medizin - Symptome & Krankheiten]] · **Register:** neutral

> [!example] Beispiel
> Welche Krankheit hat Herr Brandner?
> *Which illness does Mr Brandner have?*

**Collocations**
- an einer Krankheit leiden
- eine Krankheit behandeln
- eine chronische Krankheit
- eine Krankheit übertragen

**Related:** [[leiden]] · [[behandeln]] · [[übertragen]]

**Source:** Netzwerk neu A1 K7 9a (Arbeitsalltag) · Goethe word list A2
<!-- bank:end -->

## My notes

