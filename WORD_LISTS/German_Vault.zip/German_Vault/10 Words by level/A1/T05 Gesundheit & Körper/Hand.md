---
title: "Hand"
type: "word"
aliases: ["die Hand", "Hände"]
lemma: "Hand"
meaning: "hand"
pos: "noun"
article: "die"
plural: "Hände"
level: "A1"
topic: "[[T05 Gesundheit & Körper]]"
register: "neutral"
bank: "main"
id: "B1235"
goethe_level: "A1"
netzwerk: "A1 K8 6a"
freq_rank: 109
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T05", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# die Hand

**Meaning:** hand
**Plural:** Hände
**Level:** A1 · **Topic:** [[T05 Gesundheit & Körper]] · **Register:** neutral

> [!example] Beispiel
> Er gibt mir die Hand.
> *He shakes my hand.*

**Source:** Netzwerk neu A1 K8 6a (Fit und gesund) · Goethe word list A1
<!-- bank:end -->

## My notes

