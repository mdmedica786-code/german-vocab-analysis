---
title: "Nase"
type: "word"
aliases: ["die Nase", "Nasen"]
lemma: "Nase"
meaning: "nose"
pos: "noun"
article: "die"
plural: "Nasen"
level: "A1"
topic: "[[T05 Gesundheit & Körper]]"
register: "neutral"
bank: "main"
id: "B1246"
goethe_level: "B1"
netzwerk: "A1 K8 6b ÜB"
freq_rank: 1082
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T05", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# die Nase

**Meaning:** nose
**Plural:** Nasen
**Level:** A1 · **Topic:** [[T05 Gesundheit & Körper]] · **Register:** neutral

> [!example] Beispiel
> Haben Sie Nasentropfen? Ich bin stark erkältet.
> *Do you have nasal drops? I have a bad cold.*

**Source:** Netzwerk neu A1 K8 6b ÜB (Fit und gesund) · Goethe word list B1
<!-- bank:end -->

## My notes

