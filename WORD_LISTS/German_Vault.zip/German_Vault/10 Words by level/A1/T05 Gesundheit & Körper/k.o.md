---
title: "k.o."
type: "word"
lemma: "k.o."
meaning: "knocked out; exhausted"
pos: "adjective"
level: "A1"
topic: "[[T05 Gesundheit & Körper]]"
register: "informal"
bank: "main"
id: "B1798"
netzwerk: "A1 K12 7a"
freq_rank: 5759
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T05", "pos/adjective"]
status: "new"
---
<!-- bank:start -->
# k.o.

**Meaning:** knocked out; exhausted
**Level:** A1 · **Topic:** [[T05 Gesundheit & Körper]] · **Register:** informal

> [!example] Beispiel
> Nach der langen Reise bin ich k.o.
> *After the long journey I'm exhausted.*

**Source:** Netzwerk neu A1 K12 7a (Ab in den Urlaub!)
<!-- bank:end -->

## My notes

