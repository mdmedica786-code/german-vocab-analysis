---
title: "Doktor"
type: "word"
aliases: ["der Doktor", "Doktoren"]
lemma: "Doktor"
meaning: "doctor (m)"
pos: "noun"
article: "der"
plural: "Doktoren"
level: "A1"
topic: "[[T05 Gesundheit & Körper]]"
register: "neutral"
bank: "main"
id: "B1251"
goethe_level: "A1"
netzwerk: "A1 K8 8a"
freq_rank: 1654
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T05", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# der Doktor

**Meaning:** doctor (m)
**Plural:** Doktoren
**Level:** A1 · **Topic:** [[T05 Gesundheit & Körper]] · **Register:** neutral

> [!example] Beispiel
> Meine Tochter ist krank. Wir gehen zum Doktor.
> *My daughter is ill. We're going to the doctor.*

**Source:** Netzwerk neu A1 K8 8a (Fit und gesund) · Goethe word list A1
<!-- bank:end -->

## My notes

