---
title: "Apotheke"
type: "word"
aliases: ["die Apotheke", "Apotheken"]
lemma: "Apotheke"
meaning: "pharmacy"
pos: "noun"
article: "die"
plural: "Apotheken"
level: "A1"
topic: "[[T05 Gesundheit & Körper]]"
register: "neutral"
bank: "main"
id: "B1258"
goethe_level: "A2"
netzwerk: "A1 K8 8b"
freq_rank: 2855
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/T05", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# die Apotheke

**Meaning:** pharmacy
**Plural:** Apotheken
**Level:** A1 · **Topic:** [[T05 Gesundheit & Körper]] · **Register:** neutral

> [!example] Beispiel
> Das Medikament bekommen Sie in der Apotheke.
> *You can get the medicine at the pharmacy.*

**Source:** Netzwerk neu A1 K8 8b (Fit und gesund) · Goethe word list A2
<!-- bank:end -->

## My notes

