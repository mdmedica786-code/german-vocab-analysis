---
title: "Laborant"
type: "word"
aliases: ["der Laborant", "Laboranten"]
lemma: "Laborant"
meaning: "lab assistant (m)"
pos: "noun"
article: "der"
plural: "Laboranten"
level: "A1"
topic: "[[M4 Medizin - Klinik, Pflege & Recht]]"
register: "neutral"
bank: "main"
id: "B1316"
netzwerk: "A1 K8 13a"
freq_rank: 5759
skip: false
tags: ["vocab", "bank/main", "level/A1", "topic/M4", "pos/noun", "medical"]
status: "new"
---
<!-- bank:start -->
# der Laborant

**Meaning:** lab assistant (m)
**Plural:** Laboranten
**Forms:** den/dem/des Laboranten (n-declension)
**Level:** A1 · **Topic:** [[M4 Medizin - Klinik, Pflege & Recht]] · **Register:** neutral

> [!example] Beispiel
> Der Laborant analysiert die Blutprobe.
> *The lab assistant analyses the blood sample.*

**Source:** Netzwerk neu A1 K8 13a (Fit und gesund)
<!-- bank:end -->

## My notes

